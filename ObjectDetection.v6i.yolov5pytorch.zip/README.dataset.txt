# ObjectDetection > 2023-01-30 1:29pm
https://universe.roboflow.com/talon540/objectdetection-pmm7c

Provided by a Roboflow user
License: CC BY 4.0

